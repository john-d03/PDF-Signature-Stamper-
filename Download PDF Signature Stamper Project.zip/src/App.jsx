import BrowserPDFEditor from './BrowserPDFEditor';

export default function App() {
  return <BrowserPDFEditor />;
}